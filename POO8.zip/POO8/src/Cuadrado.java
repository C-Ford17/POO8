public class Cuadrado extends Rectangulo{

    public Cuadrado(double lado) {
        super(lado, lado);
    }
}
