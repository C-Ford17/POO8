public interface Figura {
    public String nombre();
    public double calcularArea();
    public double calcularPerimetro();
    public void dibujarTxt();
}
